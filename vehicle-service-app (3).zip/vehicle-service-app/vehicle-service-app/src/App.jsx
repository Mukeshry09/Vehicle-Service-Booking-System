import { useState, useEffect } from "react";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import BookService from "./pages/BookService";
import AdminPanel from "./pages/AdminPanel";
import Navbar from "./components/Navbar";
import { api } from "./api";

export default function App() {
  const [currentPage, setCurrentPage] = useState("home");
  const [user, setUser] = useState(null); // { name, email, role: 'user'|'admin' }
  const [loading, setLoading] = useState(true);

  // Authenticate user on startup if a token exists
  useEffect(() => {
    async function loadUser() {
      try {
        const userData = await api.getMe();
        if (userData) {
          setUser(userData);
          // Auto-route on refresh if on home page
          if (currentPage === "home" || currentPage === "login" || currentPage === "register") {
            setCurrentPage(userData.role === "admin" ? "admin" : "dashboard");
          }
        }
      } catch (err) {
        console.error("Failed to load user session:", err);
        api.logout();
      } finally {
        setLoading(false);
      }
    }
    loadUser();
  }, []);

  const navigate = (page) => setCurrentPage(page);

  const login = (userData) => {
    setUser(userData);
    navigate(userData.role === "admin" ? "admin" : "dashboard");
  };

  const logout = () => {
    api.logout();
    setUser(null);
    navigate("home");
  };

  const renderPage = () => {
    if (loading) {
      return (
        <div style={{ minHeight: "100vh", background: "#0a1628", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff" }}>
          <div style={{ textAlign: "center" }}>
            <div className="spinner-border text-success" role="status" style={{ width: "3rem", height: "3rem" }}></div>
            <div style={{ marginTop: "16px", fontFamily: "'Rajdhani', sans-serif", fontSize: "20px", fontWeight: "700" }}>Loading AutoServe...</div>
          </div>
        </div>
      );
    }

    switch (currentPage) {
      case "home":       return <Home navigate={navigate} user={user} />;
      case "login":      return <Login navigate={navigate} onLogin={login} />;
      case "register":   return <Register navigate={navigate} onLogin={login} />;
      case "dashboard":  return <Dashboard navigate={navigate} user={user} />;
      case "book":       return <BookService navigate={navigate} user={user} />;
      case "admin":      return <AdminPanel navigate={navigate} user={user} />;
      default:           return <Home navigate={navigate} user={user} />;
    }
  };

  return (
    <>
      <Navbar currentPage={currentPage} navigate={navigate} user={user} onLogout={logout} />
      {renderPage()}
    </>
  );
}
