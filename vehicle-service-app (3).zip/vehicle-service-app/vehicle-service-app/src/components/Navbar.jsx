export default function Navbar({ currentPage, navigate, user, onLogout }) {
  return (
    <nav className="navbar navbar-expand-lg sticky-top" style={{
      background: "linear-gradient(135deg, #0f2027 0%, #1a3a4a 50%, #0d3b2e 100%)",
      borderBottom: "1px solid rgba(29,158,117,0.3)",
      boxShadow: "0 2px 20px rgba(0,0,0,0.4)"
    }}>
      <div className="container">
        <a className="navbar-brand d-flex align-items-center gap-2" href="#" onClick={() => navigate("home")}>
          <div style={{
            width: 36, height: 36, borderRadius: 8,
            background: "linear-gradient(135deg, #1D9E75, #0d6e56)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 18, boxShadow: "0 0 12px rgba(29,158,117,0.5)"
          }}>🔧</div>
          <span style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 20, color: "#fff", letterSpacing: 1 }}>
            AutoServe
          </span>
        </a>

        <button className="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span style={{ color: "#1D9E75", fontSize: 22 }}>☰</span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto ms-4 gap-1">
            {[
              { label: "Home", page: "home" },
              { label: "Services", page: "services" },
            ].map(({ label, page }) => (
              <li className="nav-item" key={page}>
                <a
                  className="nav-link px-3 py-2"
                  href="#"
                  onClick={() => navigate(page)}
                  style={{
                    color: currentPage === page ? "#1D9E75" : "rgba(255,255,255,0.75)",
                    fontWeight: currentPage === page ? 600 : 400,
                    fontSize: 14,
                    borderRadius: 6,
                    transition: "all 0.2s",
                    background: currentPage === page ? "rgba(29,158,117,0.12)" : "transparent",
                  }}
                >{label}</a>
              </li>
            ))}
            {user && (
              <>
                <li className="nav-item">
                  <a className="nav-link px-3 py-2" href="#" onClick={() => navigate("dashboard")}
                    style={{ color: currentPage === "dashboard" ? "#1D9E75" : "rgba(255,255,255,0.75)", fontSize: 14, borderRadius: 6, background: currentPage === "dashboard" ? "rgba(29,158,117,0.12)" : "transparent" }}>
                    Dashboard
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link px-3 py-2" href="#" onClick={() => navigate("book")}
                    style={{ color: currentPage === "book" ? "#1D9E75" : "rgba(255,255,255,0.75)", fontSize: 14, borderRadius: 6, background: currentPage === "book" ? "rgba(29,158,117,0.12)" : "transparent" }}>
                    Book Service
                  </a>
                </li>
                {user.role === "admin" && (
                  <li className="nav-item">
                    <a className="nav-link px-3 py-2" href="#" onClick={() => navigate("admin")}
                      style={{ color: currentPage === "admin" ? "#1D9E75" : "rgba(255,255,255,0.75)", fontSize: 14, borderRadius: 6, background: currentPage === "admin" ? "rgba(29,158,117,0.12)" : "transparent" }}>
                      Admin Panel
                    </a>
                  </li>
                )}
              </>
            )}
          </ul>

          <div className="d-flex align-items-center gap-2">
            {user ? (
              <>
                <div className="d-flex align-items-center gap-2 me-2">
                  <div style={{
                    width: 32, height: 32, borderRadius: "50%",
                    background: "linear-gradient(135deg, #1D9E75, #085041)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 13, fontWeight: 700, color: "#fff"
                  }}>
                    {user.name?.charAt(0).toUpperCase()}
                  </div>
                  <span style={{ color: "rgba(255,255,255,0.85)", fontSize: 13 }}>{user.name}</span>
                  {user.role === "admin" && (
                    <span className="badge" style={{ background: "#1D9E75", fontSize: 10 }}>Admin</span>
                  )}
                </div>
                <button className="btn btn-sm" onClick={onLogout} style={{
                  border: "1px solid rgba(29,158,117,0.5)", color: "#1D9E75",
                  background: "transparent", borderRadius: 6, fontSize: 13, padding: "5px 14px"
                }}>Logout</button>
              </>
            ) : (
              <>
                <button className="btn btn-sm me-1" onClick={() => navigate("login")} style={{
                  border: "1px solid rgba(255,255,255,0.25)", color: "rgba(255,255,255,0.85)",
                  background: "transparent", borderRadius: 6, fontSize: 13, padding: "5px 14px"
                }}>Login</button>
                <button className="btn btn-sm" onClick={() => navigate("register")} style={{
                  background: "linear-gradient(135deg, #1D9E75, #0d6e56)",
                  border: "none", color: "#fff", borderRadius: 6, fontSize: 13,
                  padding: "5px 14px", boxShadow: "0 0 10px rgba(29,158,117,0.4)"
                }}>Get Started</button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
