import { useState } from "react";
import { api } from "../api";

const InputField = ({ label, name, type = "text", placeholder, value, onChange, errors }) => (
  <div className="mb-3">
    <label className="field-label d-block mb-1">{label}</label>
    <input
      type={type}
      name={name}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className={`field-input${errors[name] ? " is-invalid" : ""}`}
      onFocus={e => e.target.style.borderColor = errors[name] ? "rgba(220,53,69,0.6)" : "rgba(29,158,117,0.6)"}
      onBlur={e => e.target.style.borderColor = errors[name] ? "rgba(220,53,69,0.6)" : "rgba(255,255,255,0.12)"}
    />
    {errors[name] && <div className="field-error">⚠ {errors[name]}</div>}
  </div>
);

export default function Register({ navigate, onLogin }) {
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "", confirm: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Name is required";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = "Valid email required";
    if (!/^\d{10}$/.test(form.phone)) errs.phone = "Enter valid 10-digit phone number";
    if (form.password.length < 6) errs.password = "Minimum 6 characters";
    if (form.password !== form.confirm) errs.confirm = "Passwords do not match";
    return errs;
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setLoading(true);
    try {
      const userData = await api.register(form.name, form.email, form.phone, form.password);
      onLogin(userData);
    } catch (err) {
      setErrors({ email: err.message || "Registration failed." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <style>{`
        .page-bg {
          min-height: calc(100vh - 64px);
          background: linear-gradient(135deg, #0f2027 0%, #1a3a4a 50%, #0d3b2e 100%);
        }
        .card-glass {
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(255,255,255,0.1) !important;
          border-radius: 20px !important;
          backdrop-filter: blur(12px);
          box-shadow: 0 24px 80px rgba(0,0,0,0.5);
        }
        .brand-icon {
          width: 56px; height: 56px;
          border-radius: 14px;
          background: linear-gradient(135deg, #1D9E75, #0d6e56);
          font-size: 24px;
          box-shadow: 0 0 24px rgba(29,158,117,0.5);
        }
        .page-title {
          font-family: 'Rajdhani', sans-serif;
          font-weight: 700; font-size: 26px; color: #fff;
        }
        .page-sub { color: rgba(255,255,255,0.45); font-size: 14px; }
        .progress-bar-wrap { height: 4px; border-radius: 2px; }
        .bar-filled { background: #1D9E75; }
        .bar-empty  { background: rgba(255,255,255,0.15); }
        .step-label { font-size: 10px; color: rgba(255,255,255,0.3); }
        .field-label { color: rgba(255,255,255,0.65); font-size: 13px; font-weight: 500; }
        .field-input {
          background: rgba(255,255,255,0.06) !important;
          border: 1px solid rgba(255,255,255,0.12) !important;
          color: #fff !important;
          font-size: 14px;
          padding: 11px 14px;
          border-radius: 8px;
          outline: none;
          transition: border 0.2s;
          width: 100%;
        }
        .field-input::placeholder { color: rgba(255,255,255,0.3); }
        .field-input:focus { border-color: rgba(29,158,117,0.6) !important; box-shadow: none !important; }
        .field-input.is-invalid { border-color: rgba(220,53,69,0.6) !important; }
        .field-error { color: #ff8a8a; font-size: 12px; margin-top: 4px; }
        .terms-box {
          background: rgba(29,158,117,0.08);
          border: 1px solid rgba(29,158,117,0.2);
          border-radius: 8px;
          padding: 10px 14px;
        }
        .terms-link { color: #1D9E75; }
        .btn-submit {
          width: 100%; padding: 13px; border-radius: 8px; border: none;
          background: linear-gradient(135deg, #1D9E75, #0d6e56);
          color: #fff; font-weight: 700; font-size: 15px; cursor: pointer;
          box-shadow: 0 4px 20px rgba(29,158,117,0.4);
          font-family: 'Rajdhani', sans-serif;
          transition: all 0.2s;
        }
        .btn-submit:disabled {
          background: rgba(29,158,117,0.4);
          box-shadow: none; cursor: not-allowed;
        }
        .signin-text { color: rgba(255,255,255,0.4); font-size: 14px; }
        .btn-signin {
          background: none; border: none;
          color: #1D9E75; font-weight: 600; font-size: 14px;
          cursor: pointer; text-decoration: underline;
        }
      `}</style>

      <div className="page-bg d-flex align-items-center justify-content-center" style={{ padding: "40px 16px" }}>
        <div className="w-100" style={{ maxWidth: 480 }}>
          <div className="card-glass p-4 p-lg-5">

            <div className="text-center mb-4">
              <div className="brand-icon d-flex align-items-center justify-content-center mx-auto mb-3">🚗</div>
              <h2 className="page-title mb-1">Create Account</h2>
              <p className="page-sub mb-0">Join AutoServe today — it's free</p>
            </div>

            <div className="d-flex gap-2 mb-4">
              {["Personal Info", "Contact", "Security"].map((s, i) => (
                <div key={s} className="flex-fill text-center">
                  <div className={`progress-bar-wrap ${
                    i === 0 ? "bar-filled" :
                    i === 1 ? (form.email ? "bar-filled" : "bar-empty") :
                    (form.password ? "bar-filled" : "bar-empty")
                  }`} />
                  <div className="step-label mt-1">{s}</div>
                </div>
              ))}
            </div>

            <form onSubmit={handleSubmit}>
              <div className="row g-0">
                <div className="col-12"><InputField label="Full Name" name="name" placeholder="Rajan Kumar" value={form.name} onChange={handleChange} errors={errors} /></div>
                <div className="col-12"><InputField label="Email Address" name="email" type="email" placeholder="you@example.com" value={form.email} onChange={handleChange} errors={errors} /></div>
                <div className="col-12"><InputField label="Phone Number" name="phone" placeholder="9876543210" value={form.phone} onChange={handleChange} errors={errors} /></div>
                <div className="col-12"><InputField label="Password" name="password" type="password" placeholder="Min. 6 characters" value={form.password} onChange={handleChange} errors={errors} /></div>
                <div className="col-12"><InputField label="Confirm Password" name="confirm" type="password" placeholder="Re-enter password" value={form.confirm} onChange={handleChange} errors={errors} /></div>
              </div>

              <div className="terms-box mb-3">
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.55)" }}>
                  ✅ By registering, you agree to our{" "}
                  <span className="terms-link">Terms of Service</span> and{" "}
                  <span className="terms-link">Privacy Policy</span>
                </div>
              </div>

              <button type="submit" disabled={loading} className="btn-submit">
                {loading ? "Creating Account..." : "Create Account →"}
              </button>
            </form>

            <div className="text-center mt-4">
              <span className="signin-text">Already have an account? </span>
              <button onClick={() => navigate("login")} className="btn-signin">Sign in</button>
            </div>

          </div>
        </div>
      </div>
    </>
  );
}