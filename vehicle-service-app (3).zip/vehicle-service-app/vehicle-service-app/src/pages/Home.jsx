const services = [
  { icon: "🛢️", name: "Oil Change", desc: "Full synthetic & conventional oil change with filter replacement", price: "₹499" },
  { icon: "⚙️", name: "Engine Repair", desc: "Complete diagnostics, tune-up and engine overhaul services", price: "₹1,999" },
  { icon: "🚿", name: "Water Wash", desc: "Exterior & interior deep cleaning with premium products", price: "₹299" },
  { icon: "🔋", name: "Battery Check", desc: "Battery health test, terminal cleaning and replacement", price: "₹199" },
  { icon: "🔄", name: "Wheel Alignment", desc: "Computer-aided 4-wheel alignment and balancing", price: "₹799" },
  { icon: "🛑", name: "Brake Service", desc: "Brake pad, rotor inspection and replacement", price: "₹899" },
  { icon: "❄️", name: "AC Repair", desc: "AC gas refill, compressor check and complete servicing", price: "₹1,299" },
  { icon: "🔧", name: "Tire Replacement", desc: "Tire fitting, balancing and nitrogen inflation", price: "₹599" },
];

const stats = [
  { value: "12,000+", label: "Happy Customers" },
  { value: "50+", label: "Expert Mechanics" },
  { value: "8", label: "Service Types" },
  { value: "4.9★", label: "Average Rating" },
];

const steps = [
  { num: "01", title: "Create Account", desc: "Register and add your vehicle details in seconds." },
  { num: "02", title: "Choose Service", desc: "Pick from 8 professional vehicle services." },
  { num: "03", title: "Book a Slot", desc: "Select your preferred date and time." },
  { num: "04", title: "Track & Complete", desc: "Get real-time updates and download your invoice." },
];

export default function Home({ navigate, user }) {
  return (
    <div style={{ fontFamily: "'Rajdhani', 'Segoe UI', sans-serif", background: "#0a1628", minHeight: "100vh", color: "#fff" }}>

      {/* Hero */}
      <section style={{
        background: "linear-gradient(135deg, #0f2027 0%, #1a3a4a 40%, #0d3b2e 100%)",
        padding: "100px 0 80px", position: "relative", overflow: "hidden"
      }}>
        <div style={{
          position: "absolute", top: -100, right: -100,
          width: 500, height: 500, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(29,158,117,0.15) 0%, transparent 70%)", pointerEvents: "none"
        }} />
        <div style={{
          position: "absolute", bottom: -80, left: -80,
          width: 400, height: 400, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(29,158,117,0.08) 0%, transparent 70%)", pointerEvents: "none"
        }} />
        <div className="container">
          <div className="row align-items-center g-5">
            <div className="col-lg-6">
              <div className="badge mb-3 px-3 py-2" style={{ background: "rgba(29,158,117,0.15)", border: "1px solid rgba(29,158,117,0.4)", color: "#1D9E75", fontSize: 13, borderRadius: 20 }}>
                🚗 Professional Vehicle Care
              </div>
              <h1 style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "clamp(2.5rem,5vw,4rem)", fontWeight: 800, lineHeight: 1.1, marginBottom: 20 }}>
                Your Vehicle<br />
                <span style={{ color: "#1D9E75" }}>Deserves</span><br />
                The Best
              </h1>
              <p style={{ color: "rgba(255,255,255,0.65)", fontSize: 17, lineHeight: 1.7, marginBottom: 32, maxWidth: 480 }}>
                Book professional vehicle servicing online. Track progress in real-time. Get doorstep-ready results from certified mechanics.
              </p>
              <div className="d-flex gap-3 flex-wrap">
                <button className="btn btn-lg" onClick={() => navigate(user ? "book" : "register")} style={{
                  background: "linear-gradient(135deg, #1D9E75, #0d6e56)",
                  border: "none", color: "#fff", borderRadius: 8,
                  padding: "12px 32px", fontWeight: 600, fontSize: 15,
                  boxShadow: "0 4px 24px rgba(29,158,117,0.45)"
                }}>
                  Book a Service →
                </button>
                <button className="btn btn-lg" onClick={() => navigate("login")} style={{
                  border: "1px solid rgba(255,255,255,0.25)", color: "#fff",
                  background: "rgba(255,255,255,0.05)", borderRadius: 8,
                  padding: "12px 28px", fontWeight: 500, fontSize: 15, backdropFilter: "blur(10px)"
                }}>
                  Learn More
                </button>
              </div>
            </div>
            <div className="col-lg-6">
              <div style={{
                background: "rgba(255,255,255,0.04)", border: "1px solid rgba(29,158,117,0.2)",
                borderRadius: 20, padding: 32, backdropFilter: "blur(10px)"
              }}>
                <div className="row g-3">
                  {stats.map((s) => (
                    <div className="col-6" key={s.label}>
                      <div style={{
                        background: "rgba(29,158,117,0.08)", border: "1px solid rgba(29,158,117,0.2)",
                        borderRadius: 12, padding: "20px 16px", textAlign: "center"
                      }}>
                        <div style={{ fontSize: 28, fontWeight: 800, color: "#1D9E75", fontFamily: "'Rajdhani', sans-serif" }}>{s.value}</div>
                        <div style={{ fontSize: 13, color: "rgba(255,255,255,0.55)", marginTop: 4 }}>{s.label}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section style={{ padding: "80px 0", background: "#0a1628" }}>
        <div className="container">
          <div className="text-center mb-5">
            <span style={{ color: "#1D9E75", fontSize: 13, fontWeight: 600, letterSpacing: 2, textTransform: "uppercase" }}>What We Offer</span>
            <h2 style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "clamp(1.8rem,3vw,2.8rem)", fontWeight: 700, marginTop: 8 }}>Our Services</h2>
            <p style={{ color: "rgba(255,255,255,0.5)", maxWidth: 500, margin: "12px auto 0" }}>Professional care for every part of your vehicle</p>
          </div>
          <div className="row g-4">
            {services.map((s) => (
              <div className="col-md-6 col-lg-3" key={s.name}>
                <div style={{
                  background: "linear-gradient(135deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02))",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 16, padding: "24px 20px", height: "100%",
                  transition: "all 0.3s", cursor: "default"
                }}
                  onMouseEnter={e => {
                    e.currentTarget.style.borderColor = "rgba(29,158,117,0.4)";
                    e.currentTarget.style.transform = "translateY(-4px)";
                    e.currentTarget.style.boxShadow = "0 12px 32px rgba(29,158,117,0.15)";
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)";
                    e.currentTarget.style.transform = "translateY(0)";
                    e.currentTarget.style.boxShadow = "none";
                  }}
                >
                  <div style={{ fontSize: 32, marginBottom: 12 }}>{s.icon}</div>
                  <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 8, fontFamily: "'Rajdhani', sans-serif" }}>{s.name}</div>
                  <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 13, lineHeight: 1.6, marginBottom: 16 }}>{s.desc}</div>
                  <div style={{ color: "#1D9E75", fontWeight: 700, fontSize: 18, fontFamily: "'Rajdhani', sans-serif" }}>
                    {s.price} <span style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", fontWeight: 400 }}>onwards</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-5">
            <button className="btn" onClick={() => navigate(user ? "book" : "register")} style={{
              background: "linear-gradient(135deg, #1D9E75, #0d6e56)", border: "none",
              color: "#fff", borderRadius: 8, padding: "12px 36px", fontWeight: 600, fontSize: 15
            }}>
              Book Any Service →
            </button>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section style={{ padding: "80px 0", background: "linear-gradient(135deg, #0f1f2e, #0d2a1e)" }}>
        <div className="container">
          <div className="text-center mb-5">
            <span style={{ color: "#1D9E75", fontSize: 13, fontWeight: 600, letterSpacing: 2, textTransform: "uppercase" }}>Simple Process</span>
            <h2 style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "clamp(1.8rem,3vw,2.8rem)", fontWeight: 700, marginTop: 8 }}>How It Works</h2>
          </div>
          <div className="row g-4">
            {steps.map((s, i) => (
              <div className="col-md-6 col-lg-3" key={s.num}>
                <div style={{ textAlign: "center", padding: "20px 10px" }}>
                  <div style={{
                    width: 64, height: 64, borderRadius: "50%", margin: "0 auto 20px",
                    background: "rgba(29,158,117,0.12)", border: "2px solid rgba(29,158,117,0.3)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontFamily: "'Rajdhani', sans-serif", fontSize: 22, fontWeight: 800, color: "#1D9E75"
                  }}>{s.num}</div>
                  <h5 style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 18, marginBottom: 10 }}>{s.title}</h5>
                  <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 14, lineHeight: 1.6 }}>{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: "80px 0", background: "#0a1628" }}>
        <div className="container">
          <div style={{
            background: "linear-gradient(135deg, rgba(29,158,117,0.15), rgba(13,110,86,0.1))",
            border: "1px solid rgba(29,158,117,0.3)", borderRadius: 24, padding: "60px 40px",
            textAlign: "center"
          }}>
            <h2 style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "clamp(1.8rem,3vw,2.8rem)", fontWeight: 700, marginBottom: 16 }}>
              Ready to Book Your Service?
            </h2>
            <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 16, maxWidth: 480, margin: "0 auto 32px" }}>
              Join thousands of happy customers who trust AutoServe for their vehicle care needs.
            </p>
            <div className="d-flex gap-3 justify-content-center flex-wrap">
              <button className="btn btn-lg" onClick={() => navigate("register")} style={{
                background: "linear-gradient(135deg, #1D9E75, #0d6e56)", border: "none",
                color: "#fff", borderRadius: 8, padding: "13px 36px", fontWeight: 700, fontSize: 15
              }}>
                Create Free Account
              </button>
              <button className="btn btn-lg" onClick={() => navigate("login")} style={{
                border: "1px solid rgba(255,255,255,0.25)", color: "#fff",
                background: "transparent", borderRadius: 8, padding: "13px 28px", fontSize: 15
              }}>
                Sign In
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ borderTop: "1px solid rgba(255,255,255,0.08)", padding: "32px 0" }}>
        <div className="container d-flex flex-wrap justify-content-between align-items-center">
          <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 18 }}>🔧 AutoServe</div>
          <div style={{ color: "rgba(255,255,255,0.35)", fontSize: 13 }}>© 2025 AutoServe. All rights reserved.</div>
        </div>
      </footer>
    </div>
  );
}
