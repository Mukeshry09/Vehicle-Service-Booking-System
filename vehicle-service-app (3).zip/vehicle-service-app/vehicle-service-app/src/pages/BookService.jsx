import { useState, useEffect } from "react";
import { api } from "../api";

const TIME_SLOTS = ["09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM"];

export default function BookService({ navigate, user }) {
  const [step, setStep] = useState(1);
  const [servicesList, setServicesList] = useState([]);
  const [selectedServices, setSelectedServices] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  
  // Date and slot booking state
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [notes, setNotes] = useState("");

  // Loading and booking processing states
  const [loading, setLoading] = useState(true);
  const [bookingInProgress, setBookingInProgress] = useState(false);
  const [booked, setBooked] = useState(false);
  const [confirmedBooking, setConfirmedBooking] = useState(null);
  const [error, setError] = useState("");

  // Inline "Add Vehicle" state
  const [showAddVehicle, setShowAddVehicle] = useState(false);
  const [newVehicle, setNewVehicle] = useState({ name: "", plate: "", fuel: "Petrol", model: "2022" });
  const [addVehicleError, setAddVehicleError] = useState("");
  const [addingVehicle, setAddingVehicle] = useState(false);

  // Fetch Services & User's Vehicles on Mount
  useEffect(() => {
    if (!user) return;

    async function loadData() {
      try {
        setLoading(true);
        const [servicesData, vehiclesData] = await Promise.all([
          api.getServices(),
          api.getVehicles()
        ]);
        setServicesList(servicesData);
        setVehicles(vehiclesData);
      } catch (err) {
        console.error("Failed to load initial booking data:", err);
        setError("Failed to load active services. Please try again later.");
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [user]);

  if (!user) {
    return (
      <div style={{ minHeight: "calc(100vh - 64px)", background: "#0a1628", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div className="text-center">
          <div style={{ fontSize: 48, marginBottom: 16 }}>🔒</div>
          <h4 style={{ color: "#fff" }}>Please login to book a service</h4>
          <button onClick={() => navigate("login")} className="btn mt-3" style={{ background: "#1D9E75", color: "#fff", borderRadius: 8 }}>Login</button>
        </div>
      </div>
    );
  }

  const stepLabels = ["Select Services", "Choose Vehicle", "Pick Date & Time", "Confirm"];

  const toggleService = (s) => {
    const isSelected = selectedServices.some(item => item.id === s.id);
    if (isSelected) {
      setSelectedServices(selectedServices.filter(item => item.id !== s.id));
    } else {
      setSelectedServices([...selectedServices, s]);
    }
  };

  const handleAddVehicle = async (e) => {
    e.preventDefault();
    if (!newVehicle.name.trim() || !newVehicle.plate.trim()) {
      setAddVehicleError("Vehicle Name and License Plate are required.");
      return;
    }
    setAddingVehicle(true);
    setAddVehicleError("");
    try {
      const created = await api.addVehicle(newVehicle);
      setVehicles([...vehicles, created]);
      setSelectedVehicle(created);
      setShowAddVehicle(false);
      setNewVehicle({ name: "", plate: "", fuel: "Petrol", model: "2022" });
    } catch (err) {
      setAddVehicleError(err.message || "Failed to add vehicle.");
    } finally {
      setAddingVehicle(false);
    }
  };

  const canNext = () => {
    if (step === 1) return selectedServices.length > 0;
    if (step === 2) return !!selectedVehicle;
    if (step === 3) return date && time;
    return true;
  };

  const calculateTotal = () => {
    return selectedServices.reduce((sum, s) => sum + s.price, 0);
  };

  const handleConfirm = async () => {
    setBookingInProgress(true);
    setError("");
    try {
      const payload = {
        services: selectedServices,
        totalPrice: calculateTotal(),
        vehicle: `${selectedVehicle.name} (${selectedVehicle.plate})`,
        date,
        time,
        notes
      };
      const result = await api.createBooking(payload);
      setConfirmedBooking(result);
      setBooked(true);
    } catch (err) {
      setError(err.message || "Failed to create booking. Please try again.");
    } finally {
      setBookingInProgress(false);
    }
  };

  if (loading) {
    return (
      <div style={{ minHeight: "calc(100vh - 64px)", background: "#0a1628", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff" }}>
        <div className="text-center">
          <div className="spinner-border text-success" role="status" style={{ width: "3rem", height: "3rem" }}></div>
          <div style={{ marginTop: "16px", fontFamily: "'Rajdhani', sans-serif" }}>Loading available services...</div>
        </div>
      </div>
    );
  }

  if (booked && confirmedBooking) {
    return (
      <div style={{ minHeight: "calc(100vh - 64px)", background: "#0a1628", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
        <div style={{
          background: "rgba(255,255,255,0.04)", border: "1px solid rgba(29,158,117,0.3)",
          borderRadius: 20, padding: 40, textAlign: "center", maxWidth: 500, width: "100%"
        }}>
          <div style={{ fontSize: 56, marginBottom: 20 }}>🎉</div>
          <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 26, color: "#fff", marginBottom: 8 }}>Booking Confirmed!</div>
          <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 14, marginBottom: 24 }}>Your multi-service appointment has been scheduled.</div>
          <div style={{ background: "rgba(29,158,117,0.1)", border: "1px solid rgba(29,158,117,0.3)", borderRadius: 12, padding: "16px 20px", marginBottom: 24, textAlign: "left" }}>
            {[
              ["Booking ID", confirmedBooking.id],
              ["Services Booked", confirmedBooking.services.map(s => s.name).join(" + ")],
              ["Vehicle Attached", confirmedBooking.vehicle],
              ["Scheduled Date", `${confirmedBooking.date} at ${confirmedBooking.time}`],
              ["Total Paid", `₹${confirmedBooking.totalPrice}`],
            ].map(([k, v]) => (
              <div key={k} className="d-flex justify-content-between py-1" style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 13, marginRight: 16 }}>{k}</span>
                <span style={{ color: "#fff", fontWeight: 600, fontSize: 13, textAlign: "right" }}>{v}</span>
              </div>
            ))}
          </div>
          <div className="d-flex gap-3 justify-content-center">
            <button onClick={() => navigate("dashboard")} style={{
              background: "linear-gradient(135deg, #1D9E75, #0d6e56)", border: "none",
              color: "#fff", borderRadius: 8, padding: "11px 24px", fontWeight: 600, cursor: "pointer"
            }}>View Dashboard</button>
            <button onClick={() => { setBooked(false); setStep(1); setSelectedServices([]); setSelectedVehicle(null); setDate(""); setTime(""); setNotes(""); }} style={{
              background: "transparent", border: "1px solid rgba(255,255,255,0.2)",
              color: "#fff", borderRadius: 8, padding: "11px 20px", cursor: "pointer"
            }}>Book Another</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ background: "#0a1628", minHeight: "calc(100vh - 64px)", fontFamily: "'Rajdhani', 'Segoe UI', sans-serif" }}>
      <div className="container py-5">
        <div className="mb-5">
          <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 14, marginBottom: 8 }}>AutoServe Multi-Service Flow</div>
          <h2 style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 28, color: "#fff" }}>Schedule Your Vehicle Service</h2>
        </div>

        {/* Step Indicator */}
        <div className="d-flex align-items-center gap-2 mb-5 flex-wrap">
          {stepLabels.map((label, i) => {
            const n = i + 1;
            const done = n < step;
            const active = n === step;
            return (
              <div key={label} className="d-flex align-items-center gap-2">
                <div style={{
                  width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
                  background: done ? "#1D9E75" : active ? "rgba(29,158,117,0.15)" : "rgba(255,255,255,0.06)",
                  border: `2px solid ${done || active ? "#1D9E75" : "rgba(255,255,255,0.15)"}`,
                  color: done ? "#fff" : active ? "#1D9E75" : "rgba(255,255,255,0.3)",
                  fontSize: 13, fontWeight: 700, transition: "all 0.3s"
                }}>{done ? "✓" : n}</div>
                <span style={{ fontSize: 13, color: active ? "#1D9E75" : done ? "rgba(255,255,255,0.6)" : "rgba(255,255,255,0.3)", fontWeight: active ? 600 : 400 }}>{label}</span>
                {i < stepLabels.length - 1 && <div style={{ width: 32, height: 1, background: done ? "#1D9E75" : "rgba(255,255,255,0.1)" }} />}
              </div>
            );
          })}
        </div>

        {/* Step 1: Select Services (Supports multi-service selection) */}
        {step === 1 && (
          <div>
            <div className="d-flex justify-content-between align-items-center mb-3">
              <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 14 }}>Select one or more services to book them together</div>
              {selectedServices.length > 0 && (
                <div style={{ background: "rgba(29,158,117,0.15)", border: "1px solid #1D9E75", borderRadius: 8, padding: "4px 12px", color: "#1D9E75", fontSize: 13, fontWeight: 600 }}>
                  Selected: {selectedServices.length} | Total: ₹{calculateTotal()}
                </div>
              )}
            </div>
            <div className="row g-3">
              {servicesList.map((s) => {
                const isSelected = selectedServices.some(item => item.id === s.id);
                return (
                  <div className="col-md-6 col-lg-4" key={s.id}>
                    <div onClick={() => toggleService(s)} style={{
                      background: isSelected ? "rgba(29,158,117,0.12)" : "rgba(255,255,255,0.03)",
                      border: `1.5px solid ${isSelected ? "#1D9E75" : "rgba(255,255,255,0.08)"}`,
                      borderRadius: 14, padding: "20px 18px", cursor: "pointer",
                      position: "relative",
                      transition: "all 0.2s", boxShadow: isSelected ? "0 0 20px rgba(29,158,117,0.2)" : "none"
                    }}
                      onMouseEnter={e => { if (!isSelected) e.currentTarget.style.borderColor = "rgba(29,158,117,0.3)"; }}
                      onMouseLeave={e => { if (!isSelected) e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; }}
                    >
                      <div className="d-flex justify-content-between align-items-start">
                        <div style={{ fontSize: 28, marginBottom: 10 }}>{s.icon}</div>
                        <div style={{
                          width: 20, height: 20, borderRadius: 4, border: `1.5px solid ${isSelected ? "#1D9E75" : "rgba(255,255,255,0.3)"}`,
                          display: "flex", alignItems: "center", justifyContent: "center", background: isSelected ? "#1D9E75" : "transparent",
                          color: "#fff", fontSize: 12, fontWeight: "bold"
                        }}>
                          {isSelected && "✓"}
                        </div>
                      </div>
                      <div style={{ fontWeight: 700, fontSize: 16, color: "#fff", marginBottom: 4, fontFamily: "'Rajdhani', sans-serif" }}>{s.name}</div>
                      <div style={{ fontSize: 13, color: "rgba(255,255,255,0.45)", marginBottom: 12, lineHeight: 1.5 }}>{s.desc}</div>
                      <div className="d-flex justify-content-between align-items-center">
                        <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 18, color: "#1D9E75" }}>₹{s.price}</div>
                        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", background: "rgba(255,255,255,0.06)", padding: "3px 8px", borderRadius: 6 }}>⏱ {s.duration}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 2: Choose Vehicle (With inline "Add Vehicle" option) */}
        {step === 2 && (
          <div>
            <div className="d-flex justify-content-between align-items-center mb-3">
              <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 14 }}>Select the vehicle to service</div>
              {!showAddVehicle && (
                <button onClick={() => setShowAddVehicle(true)} style={{
                  background: "rgba(29,158,117,0.1)", border: "1px solid rgba(29,158,117,0.3)",
                  borderRadius: 6, padding: "5px 12px", color: "#1D9E75", fontSize: 13, fontWeight: 600, cursor: "pointer"
                }}>+ Add New Vehicle</button>
              )}
            </div>

            {showAddVehicle ? (
              // Inline Add Vehicle Form
              <div className="row">
                <div className="col-lg-6">
                  <form onSubmit={handleAddVehicle} style={{
                    background: "rgba(255,255,255,0.04)", border: "1px solid rgba(29,158,117,0.2)",
                    borderRadius: 16, padding: 24
                  }}>
                    <div style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: 18, fontWeight: 700, color: "#fff", marginBottom: 16 }}>➕ Add New Vehicle</div>
                    
                    <div className="row g-2 mb-3">
                      <div className="col-md-6">
                        <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 12, display: "block", marginBottom: 4 }}>Vehicle Name</label>
                        <input type="text" placeholder="e.g. Honda City" value={newVehicle.name}
                          onChange={e => setNewVehicle({ ...newVehicle, name: e.target.value })}
                          style={{ width: "100%", padding: "8px 12px", borderRadius: 6, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", fontSize: 13 }}
                        />
                      </div>
                      <div className="col-md-6">
                        <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 12, display: "block", marginBottom: 4 }}>License Plate</label>
                        <input type="text" placeholder="e.g. TN 01 AB 1234" value={newVehicle.plate}
                          onChange={e => setNewVehicle({ ...newVehicle, plate: e.target.value })}
                          style={{ width: "100%", padding: "8px 12px", borderRadius: 6, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", fontSize: 13 }}
                        />
                      </div>
                    </div>

                    <div className="row g-2 mb-3">
                      <div className="col-md-6">
                        <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 12, display: "block", marginBottom: 4 }}>Fuel Type</label>
                        <select value={newVehicle.fuel} onChange={e => setNewVehicle({ ...newVehicle, fuel: e.target.value })}
                          style={{ width: "100%", padding: "8px 12px", borderRadius: 6, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", fontSize: 13 }}>
                          <option value="Petrol">Petrol</option>
                          <option value="Diesel">Diesel</option>
                          <option value="Electric">Electric</option>
                          <option value="CNG">CNG</option>
                        </select>
                      </div>
                      <div className="col-md-6">
                        <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 12, display: "block", marginBottom: 4 }}>Model Year</label>
                        <input type="text" placeholder="e.g. 2021" value={newVehicle.model}
                          onChange={e => setNewVehicle({ ...newVehicle, model: e.target.value })}
                          style={{ width: "100%", padding: "8px 12px", borderRadius: 6, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", fontSize: 13 }}
                        />
                      </div>
                    </div>

                    {addVehicleError && <div style={{ color: "#ff8a8a", fontSize: 12, marginBottom: 12 }}>{addVehicleError}</div>}

                    <div className="d-flex gap-2">
                      <button type="submit" disabled={addingVehicle} style={{
                        background: "linear-gradient(135deg, #1D9E75, #0d6e56)", border: "none", color: "#fff",
                        borderRadius: 6, padding: "8px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer"
                      }}>
                        {addingVehicle ? "Adding..." : "Add & Select"}
                      </button>
                      <button type="button" onClick={() => setShowAddVehicle(false)} style={{
                        background: "rgba(255,255,255,0.08)", border: "none", color: "#fff",
                        borderRadius: 6, padding: "8px 14px", fontSize: 13, cursor: "pointer"
                      }}>Cancel</button>
                    </div>
                  </form>
                </div>
              </div>
            ) : (
              // Vehicles Grid
              <div className="row g-3">
                {vehicles.map((v) => {
                  const isSelected = selectedVehicle?.id === v.id;
                  return (
                    <div className="col-md-6 col-lg-5" key={v.id}>
                      <div onClick={() => setSelectedVehicle(v)} style={{
                        background: isSelected ? "rgba(29,158,117,0.12)" : "rgba(255,255,255,0.03)",
                        border: `1.5px solid ${isSelected ? "#1D9E75" : "rgba(255,255,255,0.08)"}`,
                        borderRadius: 14, padding: 24, cursor: "pointer", transition: "all 0.2s"
                      }}>
                        <div className="d-flex align-items-center justify-content-between">
                          <div className="d-flex align-items-center gap-3">
                            <div style={{ fontSize: 32 }}>🚗</div>
                            <div>
                              <div style={{ fontWeight: 700, fontSize: 17, color: "#fff", fontFamily: "'Rajdhani', sans-serif" }}>{v.name}</div>
                              <div style={{ fontSize: 13, color: "#1D9E75", fontWeight: 600 }}>{v.plate}</div>
                              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>{v.fuel} | {v.model} Model</div>
                            </div>
                          </div>
                          {isSelected && <div style={{ color: "#1D9E75", fontSize: 22 }}>✓</div>}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {vehicles.length === 0 && (
                  <div className="col-12 py-4">
                    <div style={{
                      background: "rgba(255,255,255,0.02)", border: "1px dashed rgba(255,255,255,0.1)",
                      borderRadius: 16, padding: "40px", textAlignment: "center", color: "rgba(255,255,255,0.4)"
                    }}>
                      <div style={{ fontSize: 36, marginBottom: 12 }}>🚗</div>
                      <div style={{ fontWeight: 600, color: "#fff", marginBottom: 4 }}>No Registered Vehicles</div>
                      <div style={{ fontSize: 13, marginBottom: 20 }}>Please register a vehicle to continue service scheduling.</div>
                      <button onClick={() => setShowAddVehicle(true)} style={{
                        background: "linear-gradient(135deg, #1D9E75, #0d6e56)", border: "none", color: "#fff",
                        borderRadius: 6, padding: "8px 20px", fontSize: 13, fontWeight: 600, cursor: "pointer"
                      }}>+ Add Your First Vehicle</button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Step 3: Pick Date & Time */}
        {step === 3 && (
          <div style={{ maxWidth: 520 }}>
            <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 14, marginBottom: 24 }}>Choose your preferred date and time slot</div>
            <div className="mb-4">
              <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, fontWeight: 500, display: "block", marginBottom: 8 }}>Select Date</label>
              <input type="date" value={date} onChange={e => setDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
                style={{
                  background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
                  borderRadius: 8, padding: "11px 14px", color: "#fff", fontSize: 15, width: "100%", outline: "none"
                }}
              />
            </div>
            <div className="mb-4">
              <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, fontWeight: 500, display: "block", marginBottom: 8 }}>Select Time Slot</label>
              <div className="d-flex flex-wrap gap-2">
                {TIME_SLOTS.map((t) => (
                  <button key={t} onClick={() => setTime(t)} style={{
                    padding: "9px 16px", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer",
                    background: time === t ? "rgba(29,158,117,0.15)" : "rgba(255,255,255,0.05)",
                    border: `1.5px solid ${time === t ? "#1D9E75" : "rgba(255,255,255,0.1)"}`,
                    color: time === t ? "#1D9E75" : "rgba(255,255,255,0.6)", transition: "all 0.15s"
                  }}>{t}</button>
                ))}
              </div>
            </div>
            <div>
              <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, fontWeight: 500, display: "block", marginBottom: 8 }}>Additional Notes (optional)</label>
              <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={3} placeholder="Any specific issue or request..."
                style={{
                  width: "100%", padding: "11px 14px", borderRadius: 8, fontSize: 14,
                  background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
                  color: "#fff", outline: "none", resize: "vertical"
                }}
              />
            </div>
          </div>
        )}

        {/* Step 4: Confirm (Accommodates list of multiple services) */}
        {step === 4 && (
          <div style={{ maxWidth: 540 }}>
            <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 14, marginBottom: 24 }}>Review and confirm your booking details</div>
            <div style={{
              background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 16, padding: 28, marginBottom: 20
            }}>
              <div style={{ fontWeight: 600, color: "rgba(255,255,255,0.45)", fontSize: 13, marginBottom: 12 }}>Selected Services</div>
              
              <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 24 }}>
                {selectedServices.map(s => (
                  <div key={s.id} className="d-flex align-items-center gap-3 p-3" style={{ background: "rgba(255,255,255,0.03)", borderRadius: 12, border: "1px solid rgba(255,255,255,0.05)" }}>
                    <div style={{ fontSize: 24 }}>{s.icon}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 16, color: "#fff" }}>{s.name}</div>
                      <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>⏱ {s.duration}</div>
                    </div>
                    <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 16, color: "#1D9E75" }}>₹{s.price}</div>
                  </div>
                ))}
              </div>

              {[
                ["🚗 Selected Vehicle", `${selectedVehicle?.name} (${selectedVehicle?.plate})`],
                ["📅 Appt. Date", date],
                ["⏰ Time Slot", time],
                notes && ["📝 Special Notes", notes],
              ].filter(Boolean).map(([k, v]) => (
                <div key={k} className="d-flex justify-content-between py-2" style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                  <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 14 }}>{k}</span>
                  <span style={{ color: "#fff", fontWeight: 500, fontSize: 14 }}>{v}</span>
                </div>
              ))}

              <div className="d-flex justify-content-between pt-3 mt-2" style={{ borderTop: "1.5px solid rgba(29,158,117,0.3)" }}>
                <span style={{ color: "rgba(255,255,255,0.65)", fontWeight: 600 }}>Total Service Amount</span>
                <span style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 22, color: "#1D9E75" }}>₹{calculateTotal()}</span>
              </div>
            </div>

            {error && <div style={{ background: "rgba(220,53,69,0.15)", border: "1px solid rgba(220,53,69,0.3)", color: "#ff8a8a", padding: "10px 14px", borderRadius: 8, fontSize: 13, marginBottom: 16 }}>{error}</div>}
          </div>
        )}

        {/* Navigation buttons */}
        <div className="d-flex gap-3 mt-5">
          {step > 1 && !showAddVehicle && (
            <button onClick={() => setStep(step - 1)} style={{
              background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.15)",
              color: "#fff", borderRadius: 8, padding: "11px 24px", fontWeight: 600, cursor: "pointer", fontSize: 14
            }}>← Back</button>
          )}
          {step < 4 ? (
            !showAddVehicle && (
              <button onClick={() => setStep(step + 1)} disabled={!canNext()} style={{
                background: canNext() ? "linear-gradient(135deg, #1D9E75, #0d6e56)" : "rgba(255,255,255,0.1)",
                border: "none", color: canNext() ? "#fff" : "rgba(255,255,255,0.3)",
                borderRadius: 8, padding: "11px 28px", fontWeight: 700, cursor: canNext() ? "pointer" : "not-allowed", fontSize: 14,
                boxShadow: canNext() ? "0 4px 16px rgba(29,158,117,0.35)" : "none"
              }}>Next →</button>
            )
          ) : (
            <button onClick={handleConfirm} disabled={bookingInProgress} style={{
              background: "linear-gradient(135deg, #1D9E75, #0d6e56)", border: "none",
              color: "#fff", borderRadius: 8, padding: "11px 28px",
              fontWeight: 700, cursor: bookingInProgress ? "not-allowed" : "pointer", fontSize: 15,
              boxShadow: "0 4px 20px rgba(29,158,117,0.45)"
            }}>
              {bookingInProgress ? "⌛ Reserving Slots..." : "✅ Confirm Booking"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
