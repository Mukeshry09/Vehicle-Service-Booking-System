import { useState, useEffect } from "react";
import { api } from "../api";

const STATUS_STYLES = {
  Completed:  { bg: "rgba(29,158,117,0.12)", border: "rgba(29,158,117,0.3)", color: "#1D9E75", dot: "#1D9E75" },
  "In Service": { bg: "rgba(99,130,255,0.12)", border: "rgba(99,130,255,0.3)", color: "#8fa7ff", dot: "#8fa7ff" },
  Confirmed:  { bg: "rgba(255,193,7,0.12)", border: "rgba(255,193,7,0.3)", color: "#ffc107", dot: "#ffc107" },
  Pending:    { bg: "rgba(108,117,125,0.12)", border: "rgba(108,117,125,0.3)", color: "#9ca3af", dot: "#9ca3af" },
};

const PROGRESS_STEPS = ["Pending", "Confirmed", "In Service", "Completed"];

export default function Dashboard({ navigate, user }) {
  const [bookings, setBookings] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [activeTab, setActiveTab] = useState("bookings");
  const [selectedBooking, setSelectedBooking] = useState(null);
  
  // Loading & error states
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Add Vehicle State
  const [showAddVehicle, setShowAddVehicle] = useState(false);
  const [newVehicle, setNewVehicle] = useState({ name: "", plate: "", fuel: "Petrol", model: "2022" });
  const [addingVehicle, setAddingVehicle] = useState(false);
  const [addVehicleError, setAddVehicleError] = useState("");

  // Fetch bookings and vehicles on mount
  const loadDashboardData = async () => {
    try {
      setLoading(true);
      setError("");
      const [bookingsData, vehiclesData] = await Promise.all([
        api.getBookings(),
        api.getVehicles()
      ]);
      setBookings(bookingsData);
      setVehicles(vehiclesData);
    } catch (err) {
      console.error("Failed to load dashboard data:", err);
      setError("Unable to sync data with the server. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user) return;
    loadDashboardData();
  }, [user]);

  if (!user) {
    return (
      <div style={{ minHeight: "calc(100vh - 64px)", background: "#0a1628", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div className="text-center">
          <div style={{ fontSize: 48, marginBottom: 16 }}>🔒</div>
          <h4 style={{ color: "#fff" }}>Please login to view your dashboard</h4>
          <button onClick={() => navigate("login")} className="btn mt-3" style={{ background: "#1D9E75", color: "#fff", borderRadius: 8 }}>Login</button>
        </div>
      </div>
    );
  }

  const handleAddVehicle = async (e) => {
    e.preventDefault();
    if (!newVehicle.name.trim() || !newVehicle.plate.trim()) {
      setAddVehicleError("Vehicle Name and license plate number are required.");
      return;
    }
    setAddingVehicle(true);
    setAddVehicleError("");
    try {
      const added = await api.addVehicle(newVehicle);
      setVehicles([...vehicles, added]);
      setShowAddVehicle(false);
      setNewVehicle({ name: "", plate: "", fuel: "Petrol", model: "2022" });
    } catch (err) {
      setAddVehicleError(err.message || "Failed to add vehicle.");
    } finally {
      setAddingVehicle(false);
    }
  };

  const handleDeleteVehicle = async (id) => {
    if (!window.confirm("Are you sure you want to remove this vehicle?")) return;
    try {
      await api.deleteVehicle(id);
      setVehicles(vehicles.filter(v => v.id !== id));
    } catch (err) {
      alert("Failed to delete vehicle: " + err.message);
    }
  };

  // Stats calculation
  const completedCount = bookings.filter(b => b.status === "Completed").length;
  const inProgressCount = bookings.filter(b => ["In Service", "Confirmed"].includes(b.status)).length;
  const totalSpent = bookings.filter(b => b.status === "Completed").reduce((s, b) => s + b.totalPrice, 0);

  const stats = [
    { label: "Total Bookings", value: bookings.length, icon: "📋", color: "#1D9E75" },
    { label: "Completed", value: completedCount, icon: "✅", color: "#1D9E75" },
    { label: "In Progress", value: inProgressCount, icon: "⚙️", color: "#8fa7ff" },
    { label: "Total Spent", value: `₹${totalSpent.toLocaleString()}`, icon: "💰", color: "#ffc107" },
  ];

  if (loading && bookings.length === 0 && vehicles.length === 0) {
    return (
      <div style={{ minHeight: "calc(100vh - 64px)", background: "#0a1628", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff" }}>
        <div className="text-center">
          <div className="spinner-border text-success" role="status" style={{ width: "3rem", height: "3rem" }}></div>
          <div style={{ marginTop: "16px", fontFamily: "'Rajdhani', sans-serif" }}>Synchronizing profile details...</div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ background: "#0a1628", minHeight: "calc(100vh - 64px)", fontFamily: "'Rajdhani', 'Segoe UI', sans-serif" }}>
      <div className="container py-5">

        {/* Header */}
        <div className="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
          <div>
            <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 14, marginBottom: 4 }}>Welcome back 👋</div>
            <h2 style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 28, color: "#fff", margin: 0 }}>{user.name}</h2>
          </div>
          <button onClick={() => navigate("book")} style={{
            background: "linear-gradient(135deg, #1D9E75, #0d6e56)", border: "none",
            color: "#fff", borderRadius: 8, padding: "10px 24px",
            fontWeight: 600, fontSize: 14, cursor: "pointer"
          }}>+ Book New Service</button>
        </div>

        {/* Error message */}
        {error && (
          <div style={{ background: "rgba(220,53,69,0.12)", border: "1px solid rgba(220,53,69,0.3)", color: "#ff8a8a", padding: "10px 14px", borderRadius: 8, fontSize: 13, marginBottom: 20 }}>
            {error}
          </div>
        )}

        {/* Stats */}
        <div className="row g-3 mb-4">
          {stats.map((s) => (
            <div className="col-6 col-md-3" key={s.label}>
              <div style={{
                background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 14, padding: "20px 18px"
              }}>
                <div style={{ fontSize: 24, marginBottom: 8 }}>{s.icon}</div>
                <div style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: 26, fontWeight: 700, color: s.color }}>{s.value}</div>
                <div style={{ fontSize: 13, color: "rgba(255,255,255,0.45)" }}>{s.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="d-flex gap-1 mb-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)", paddingBottom: 0 }}>
          {[["bookings", "📋 My Bookings"], ["vehicles", "🚗 My Vehicles"], ["profile", "👤 Profile"]].map(([key, label]) => (
            <button key={key} onClick={() => { setActiveTab(key); setSelectedBooking(null); }} style={{
              background: activeTab === key ? "rgba(29,158,117,0.12)" : "transparent",
              border: "none", borderBottom: activeTab === key ? "2px solid #1D9E75" : "2px solid transparent",
              color: activeTab === key ? "#1D9E75" : "rgba(255,255,255,0.45)",
              padding: "10px 18px", fontSize: 14, fontWeight: activeTab === key ? 600 : 400,
              cursor: "pointer", borderRadius: "6px 6px 0 0", transition: "all 0.2s"
            }}>{label}</button>
          ))}
        </div>

        {/* Bookings Tab */}
        {activeTab === "bookings" && (
          <div>
            {selectedBooking ? (
              // Detail view (Supports rendering multiple services)
              <div style={{
                background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: 16, padding: 28
              }}>
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <div>
                    <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 13 }}>Booking ID</div>
                    <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 22, color: "#fff" }}>{selectedBooking.id}</div>
                  </div>
                  <button onClick={() => setSelectedBooking(null)} style={{
                    background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.15)",
                    color: "#fff", borderRadius: 8, padding: "7px 16px", cursor: "pointer", fontSize: 13
                  }}>← Back</button>
                </div>

                {/* Progress bar */}
                <div className="mb-4">
                  <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 13, marginBottom: 12 }}>Service Progress</div>
                  <div className="d-flex align-items-center gap-2 flex-wrap">
                    {PROGRESS_STEPS.map((step, i) => {
                      const currentIdx = PROGRESS_STEPS.indexOf(selectedBooking.status);
                      const done = i <= currentIdx;
                      return (
                        <div key={step} className="d-flex align-items-center gap-2">
                          <div style={{
                            width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center",
                            justifyContent: "center", fontSize: 13,
                            background: done ? "#1D9E75" : "rgba(255,255,255,0.08)",
                            border: `2px solid ${done ? "#1D9E75" : "rgba(255,255,255,0.2)"}`,
                            color: done ? "#fff" : "rgba(255,255,255,0.3)", fontWeight: 700
                          }}>{done ? "✓" : i + 1}</div>
                          <div style={{ fontSize: 12, color: done ? "#1D9E75" : "rgba(255,255,255,0.35)", fontWeight: done ? 600 : 400 }}>{step}</div>
                          {i < PROGRESS_STEPS.length - 1 && (
                            <div style={{ width: 24, height: 2, background: done && i < currentIdx ? "#1D9E75" : "rgba(255,255,255,0.1)", borderRadius: 1 }} />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Services list inside details */}
                <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 12, padding: 18, marginBottom: 20 }}>
                  <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginBottom: 12 }}>Booked Services</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {selectedBooking.services && selectedBooking.services.map(s => (
                      <div key={s.id} className="d-flex align-items-center gap-3 p-2" style={{ background: "rgba(255,255,255,0.02)", borderRadius: 8 }}>
                        <div style={{ fontSize: 20 }}>{s.icon}</div>
                        <div style={{ flex: 1, color: "#fff", fontWeight: 600, fontSize: 14 }}>{s.name}</div>
                        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", marginRight: 16 }}>⏱ {s.duration}</div>
                        <div style={{ color: "#1D9E75", fontWeight: 700, fontSize: 14 }}>₹{s.price}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="row g-3">
                  {[
                    ["Vehicle Scheduled", selectedBooking.vehicle],
                    ["Appointment Date", selectedBooking.date],
                    ["Scheduled Time", selectedBooking.time],
                    ["Assigned Mechanic", selectedBooking.mechanic],
                    ["Notes Given", selectedBooking.notes || "None"],
                    ["Total Amount Paid", `₹${selectedBooking.totalPrice}`],
                  ].map(([k, v]) => (
                    <div className="col-md-6" key={k}>
                      <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: "14px 16px", border: "1px solid rgba(255,255,255,0.08)" }}>
                        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 4 }}>{k}</div>
                        <div style={{ fontWeight: 600, color: "#fff", fontSize: 15 }}>{v}</div>
                      </div>
                    </div>
                  ))}
                </div>

                {selectedBooking.status === "Completed" && (
                  <button className="btn mt-4" style={{
                    background: "rgba(29,158,117,0.15)", border: "1px solid rgba(29,158,117,0.4)",
                    color: "#1D9E75", borderRadius: 8, padding: "10px 24px", fontWeight: 600
                  }}>📄 Download Invoice</button>
                )}
              </div>
            ) : (
              // List view
              <div className="d-flex flex-column gap-3">
                {bookings.map((b) => {
                  const st = STATUS_STYLES[b.status] || STATUS_STYLES.Pending;
                  const servicesText = b.services ? b.services.map(s => s.name).join(" + ") : b.service;
                  return (
                    <div key={b.id} onClick={() => setSelectedBooking(b)} style={{
                      background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
                      borderRadius: 14, padding: "20px 22px", cursor: "pointer", transition: "all 0.2s"
                    }}
                      onMouseEnter={e => { e.currentTarget.style.borderColor = "rgba(29,158,117,0.3)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
                      onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; e.currentTarget.style.transform = "translateY(0)"; }}
                    >
                      <div className="d-flex flex-wrap justify-content-between align-items-start gap-3">
                        <div>
                          <div className="d-flex align-items-center gap-2 mb-1">
                            <span style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 17, color: "#fff" }}>{servicesText}</span>
                            <span style={{ fontSize: 11, background: st.bg, border: `1px solid ${st.border}`, color: st.color, padding: "2px 10px", borderRadius: 20, fontWeight: 600 }}>
                              ● {b.status}
                            </span>
                          </div>
                          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.45)" }}>🚗 {b.vehicle}</div>
                          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.45)", marginTop: 2 }}>📅 {b.date} at {b.time}</div>
                        </div>
                        <div className="text-end">
                          <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 20, color: "#1D9E75" }}>₹{b.totalPrice || b.price}</div>
                          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.35)" }}>ID: {b.id}</div>
                          <div style={{ fontSize: 12, color: "#1D9E75", marginTop: 4 }}>View Details →</div>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {bookings.length === 0 && (
                  <div style={{ textAlign: "center", padding: "40px", color: "rgba(255,255,255,0.3)", fontSize: 14 }}>
                    No service bookings scheduled yet. Click "+ Book New Service" to start!
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Vehicles Tab (Fully functional vehicle manager) */}
        {activeTab === "vehicles" && (
          <div>
            {showAddVehicle ? (
              // Add vehicle form card
              <div className="col-lg-6 mb-4">
                <form onSubmit={handleAddVehicle} style={{
                  background: "rgba(255,255,255,0.04)", border: "1px solid rgba(29,158,117,0.3)",
                  borderRadius: 16, padding: 28
                }}>
                  <h4 style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, color: "#fff", marginBottom: 20 }}>➕ Register New Vehicle</h4>
                  
                  <div className="mb-3">
                    <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, display: "block", marginBottom: 6 }}>Vehicle Manufacturer & Model</label>
                    <input type="text" placeholder="e.g. Honda City" value={newVehicle.name}
                      onChange={e => setNewVehicle({ ...newVehicle, name: e.target.value })}
                      style={{ width: "100%", padding: "10px 14px", borderRadius: 8, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", outline: "none" }}
                    />
                  </div>

                  <div className="mb-3">
                    <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, display: "block", marginBottom: 6 }}>License Plate Number</label>
                    <input type="text" placeholder="e.g. TN 01 AB 1234" value={newVehicle.plate}
                      onChange={e => setNewVehicle({ ...newVehicle, plate: e.target.value })}
                      style={{ width: "100%", padding: "10px 14px", borderRadius: 8, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", outline: "none" }}
                    />
                  </div>

                  <div className="row g-3 mb-4">
                    <div className="col-6">
                      <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, display: "block", marginBottom: 6 }}>Fuel Type</label>
                      <select value={newVehicle.fuel} onChange={e => setNewVehicle({ ...newVehicle, fuel: e.target.value })}
                        style={{ width: "100%", padding: "10px 14px", borderRadius: 8, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", outline: "none" }}>
                        <option value="Petrol">Petrol</option>
                        <option value="Diesel">Diesel</option>
                        <option value="Electric">Electric</option>
                        <option value="CNG">CNG</option>
                      </select>
                    </div>
                    <div className="col-6">
                      <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, display: "block", marginBottom: 6 }}>Model Year</label>
                      <input type="text" placeholder="e.g. 2021" value={newVehicle.model}
                        onChange={e => setNewVehicle({ ...newVehicle, model: e.target.value })}
                        style={{ width: "100%", padding: "10px 14px", borderRadius: 8, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", outline: "none" }}
                      />
                    </div>
                  </div>

                  {addVehicleError && <div style={{ color: "#ff8a8a", fontSize: 13, marginBottom: 16 }}>{addVehicleError}</div>}

                  <div className="d-flex gap-2">
                    <button type="submit" disabled={addingVehicle} style={{
                      background: "linear-gradient(135deg, #1D9E75, #0d6e56)", border: "none", color: "#fff",
                      borderRadius: 8, padding: "10px 20px", fontSize: 14, fontWeight: 600, cursor: "pointer"
                    }}>{addingVehicle ? "Adding..." : "Save Vehicle"}</button>
                    <button type="button" onClick={() => setShowAddVehicle(false)} style={{
                      background: "rgba(255,255,255,0.08)", border: "none", color: "#fff",
                      borderRadius: 8, padding: "10px 18px", fontSize: 14, cursor: "pointer"
                    }}>Cancel</button>
                  </div>
                </form>
              </div>
            ) : null}

            <div className="row g-3">
              {vehicles.map((v) => (
                <div className="col-md-6" key={v.id}>
                  <div style={{
                    background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
                    borderRadius: 14, padding: "22px 24px", position: "relative"
                  }}>
                    <button onClick={() => handleDeleteVehicle(v.id)} style={{
                      position: "absolute", top: 18, right: 18, background: "rgba(220, 53, 69, 0.15)", border: "none",
                      color: "#ff8a8a", width: 28, height: 28, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
                      cursor: "pointer", fontSize: 12
                    }} title="Delete Vehicle">✕</button>

                    <div className="d-flex align-items-center gap-3 mb-3">
                      <div style={{ fontSize: 36 }}>🚗</div>
                      <div>
                        <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 18, color: "#fff" }}>{v.name}</div>
                        <div style={{ fontSize: 13, color: "#1D9E75", fontWeight: 600 }}>{v.plate}</div>
                      </div>
                    </div>
                    <div className="d-flex gap-3">
                      {[["Model", v.model], ["Fuel", v.fuel]].map(([k, val]) => (
                        <div key={k} style={{ background: "rgba(255,255,255,0.06)", borderRadius: 8, padding: "8px 14px", flex: 1 }}>
                          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>{k}</div>
                          <div style={{ fontSize: 14, fontWeight: 600, color: "#fff" }}>{val}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}

              {!showAddVehicle && (
                <div className="col-md-6">
                  <div onClick={() => setShowAddVehicle(true)} style={{
                    background: "rgba(29,158,117,0.05)", border: "1px dashed rgba(29,158,117,0.3)",
                    borderRadius: 14, padding: "22px 24px", cursor: "pointer",
                    display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 145
                  }}>
                    <div style={{ fontSize: 28, marginBottom: 8 }}>➕</div>
                    <div style={{ color: "#1D9E75", fontWeight: 600, fontSize: 15 }}>Add New Vehicle</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Profile Tab */}
        {activeTab === "profile" && (
          <div style={{
            background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: 16, padding: 28, maxWidth: 520
          }}>
            <div className="d-flex align-items-center gap-4 mb-4">
              <div style={{
                width: 64, height: 64, borderRadius: "50%",
                background: "linear-gradient(135deg, #1D9E75, #085041)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 26, fontWeight: 700, color: "#fff"
              }}>{user.name.charAt(0)}</div>
              <div>
                <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 22, color: "#fff" }}>{user.name}</div>
                <div style={{ fontSize: 14, color: "rgba(255,255,255,0.45)" }}>{user.email}</div>
                <div className="badge mt-1" style={{ background: "rgba(29,158,117,0.15)", color: "#1D9E75", fontSize: 11 }}>
                  {user.role === "admin" ? "👑 Admin" : "🚗 Customer"}
                </div>
              </div>
            </div>
            {[
              ["Full Name", user.name],
              ["Email Address", user.email],
              ["Phone Contact", user.phone || "None Given"],
              ["Member Since", user.joined || "May 2025"],
              ["Total Booking Count", bookings.length]
            ].map(([k, v]) => (
              <div key={k} className="d-flex justify-content-between py-3" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
                <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 14 }}>{k}</span>
                <span style={{ color: "#fff", fontWeight: 600, fontSize: 14 }}>{v}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
