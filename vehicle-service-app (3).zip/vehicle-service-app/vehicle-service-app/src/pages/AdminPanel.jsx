import { useState, useEffect } from "react";
import { api } from "../api";

const STATUS_STYLES = {
  Completed:  { bg: "rgba(29,158,117,0.12)", border: "rgba(29,158,117,0.3)", color: "#1D9E75" },
  "In Service": { bg: "rgba(99,130,255,0.12)", border: "rgba(99,130,255,0.3)", color: "#8fa7ff" },
  Confirmed:  { bg: "rgba(255,193,7,0.12)", border: "rgba(255,193,7,0.3)", color: "#ffc107" },
  Pending:    { bg: "rgba(108,117,125,0.12)", border: "rgba(108,117,125,0.3)", color: "#9ca3af" },
};

export default function AdminPanel({ navigate, user }) {
  const [bookings, setBookings] = useState([]);
  const [mechanics, setMechanics] = useState([]);
  const [activeTab, setActiveTab] = useState("bookings");
  const [filterStatus, setFilterStatus] = useState("All");
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Sync data from Express API
  const loadAdminData = async () => {
    try {
      setLoading(true);
      setError("");
      const [bookingsData, mechanicsData] = await Promise.all([
        api.getBookings(),
        api.getMechanics()
      ]);
      setBookings(bookingsData);
      setMechanics(mechanicsData);
    } catch (err) {
      console.error("Admin Panel failed to fetch data:", err);
      setError("Failed to synchronize control panel. " + err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user || user.role !== "admin") return;
    loadAdminData();
  }, [user]);

  if (!user || user.role !== "admin") {
    return (
      <div style={{ minHeight: "calc(100vh - 64px)", background: "#0a1628", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div className="text-center">
          <div style={{ fontSize: 48, marginBottom: 16 }}>🚫</div>
          <h4 style={{ color: "#fff" }}>Admin Access Required</h4>
          <p style={{ color: "rgba(255,255,255,0.45)", fontSize: 14 }}>Please login with admin account</p>
          <button onClick={() => navigate("login")} className="btn mt-3" style={{ background: "#1D9E75", color: "#fff", borderRadius: 8 }}>Login as Admin</button>
        </div>
      </div>
    );
  }

  const filteredBookings = bookings.filter(b => {
    const matchStatus = filterStatus === "All" || b.status === filterStatus;
    
    const servicesText = b.services ? b.services.map(s => s.name).join(" ") : b.service || "";
    const matchSearch = b.user.toLowerCase().includes(search.toLowerCase()) ||
      servicesText.toLowerCase().includes(search.toLowerCase()) ||
      b.id.toLowerCase().includes(search.toLowerCase());
      
    return matchStatus && matchSearch;
  });

  // Calculate dynamic stats
  const completedBookings = bookings.filter(b => b.status === "Completed");
  const revenue = completedBookings.reduce((s, b) => s + (b.totalPrice || b.price), 0);
  const pendingCount = bookings.filter(b => b.status === "Pending").length;
  const inProgressCount = bookings.filter(b => ["In Service", "Confirmed"].includes(b.status)).length;

  const stats = [
    { label: "Total Bookings", value: bookings.length, icon: "📋", color: "#fff" },
    { label: "Pending", value: pendingCount, icon: "⏳", color: "#9ca3af" },
    { label: "In Progress", value: inProgressCount, icon: "⚙️", color: "#8fa7ff" },
    { label: "Completed", value: completedBookings.length, icon: "✅", color: "#1D9E75" },
    { label: "Total Revenue", value: `₹${revenue.toLocaleString()}`, icon: "💰", color: "#ffc107" },
  ];

  const startEdit = (b) => {
    setEditingId(b.id);
    setEditData({ status: b.status, mechanic: b.mechanic });
  };

  const saveEdit = async (id) => {
    try {
      setError("");
      const updated = await api.updateBookingAdmin(id, editData);
      setBookings(bookings.map(b => b.id === id ? updated : b));
      setEditingId(null);
    } catch (err) {
      setError("Failed to update booking status: " + err.message);
    }
  };

  if (loading && bookings.length === 0) {
    return (
      <div style={{ minHeight: "calc(100vh - 64px)", background: "#0a1628", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff" }}>
        <div className="text-center">
          <div className="spinner-border text-success" role="status" style={{ width: "3rem", height: "3rem" }}></div>
          <div style={{ marginTop: "16px", fontFamily: "'Rajdhani', sans-serif" }}>Loading control dashboard...</div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ background: "#0a1628", minHeight: "calc(100vh - 64px)", fontFamily: "'Rajdhani', 'Segoe UI', sans-serif" }}>
      <div className="container-fluid py-4 px-4">

        {/* Header */}
        <div className="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
          <div>
            <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 14 }}>Admin Control Dashboard</div>
            <h2 style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 26, color: "#fff", margin: 0 }}>Control Panel</h2>
          </div>
          <div className="badge px-3 py-2" style={{ background: "rgba(29,158,117,0.15)", border: "1px solid rgba(29,158,117,0.3)", color: "#1D9E75", fontSize: 13 }}>
            👑 {user.name} (Admin)
          </div>
        </div>

        {/* Errors */}
        {error && (
          <div style={{ background: "rgba(220,53,69,0.15)", border: "1px solid rgba(220,53,69,0.3)", color: "#ff8a8a", padding: "10px 14px", borderRadius: 8, fontSize: 13, marginBottom: 20 }}>
            {error}
          </div>
        )}

        {/* Stats */}
        <div className="row g-3 mb-4">
          {stats.map((s) => (
            <div className="col-6 col-md-4 col-lg-2" key={s.label} style={{ flex: 1, minWidth: 130 }}>
              <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 12, padding: "18px 16px" }}>
                <div style={{ fontSize: 22, marginBottom: 6 }}>{s.icon}</div>
                <div style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: 24, fontWeight: 700, color: s.color }}>{s.value}</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>{s.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="d-flex gap-1 mb-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          {[["bookings", "📋 Bookings"], ["users", "👥 Customers"], ["mechanics", "🔧 Mechanics"]].map(([key, label]) => (
            <button key={key} onClick={() => setActiveTab(key)} style={{
              background: activeTab === key ? "rgba(29,158,117,0.12)" : "transparent",
              border: "none", borderBottom: activeTab === key ? "2px solid #1D9E75" : "2px solid transparent",
              color: activeTab === key ? "#1D9E75" : "rgba(255,255,255,0.45)",
              padding: "9px 18px", fontSize: 14, fontWeight: activeTab === key ? 600 : 400,
              cursor: "pointer", borderRadius: "6px 6px 0 0", transition: "all 0.2s"
            }}>{label}</button>
          ))}
        </div>

        {/* Bookings Tab */}
        {activeTab === "bookings" && (
          <>
            {/* Filters */}
            <div className="d-flex flex-wrap gap-3 mb-4 align-items-center">
              <input
                type="text" placeholder="🔍 Search by name, service, or ID..." value={search}
                onChange={e => setSearch(e.target.value)}
                style={{
                  background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
                  borderRadius: 8, padding: "9px 14px", color: "#fff", fontSize: 13,
                  width: 280, outline: "none"
                }}
              />
              <div className="d-flex gap-2 flex-wrap">
                {["All", "Pending", "Confirmed", "In Service", "Completed"].map(s => (
                  <button key={s} onClick={() => setFilterStatus(s)} style={{
                    padding: "7px 14px", borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: "pointer",
                    background: filterStatus === s ? "rgba(29,158,117,0.2)" : "rgba(255,255,255,0.05)",
                    border: `1px solid ${filterStatus === s ? "rgba(29,158,117,0.5)" : "rgba(255,255,255,0.1)"}`,
                    color: filterStatus === s ? "#1D9E75" : "rgba(255,255,255,0.5)", transition: "all 0.15s"
                  }}>{s}</button>
                ))}
              </div>
            </div>

            {/* Table */}
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
                    {["Booking ID", "Customer", "Services Booked", "Vehicle Attached", "Scheduled Date", "Status", "Mechanic Assigned", "Price", "Actions"].map(h => (
                      <th key={h} style={{ padding: "10px 14px", color: "rgba(255,255,255,0.4)", fontWeight: 600, textAlign: "left", whiteSpace: "nowrap", fontSize: 12 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredBookings.map((b) => {
                    const st = STATUS_STYLES[b.status] || STATUS_STYLES.Pending;
                    const isEditing = editingId === b.id;
                    const servicesText = b.services ? b.services.map(s => s.name).join(" + ") : b.service;
                    
                    return (
                      <tr key={b.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.05)", transition: "background 0.15s" }}
                        onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.03)"}
                        onMouseLeave={e => e.currentTarget.style.background = "transparent"}
                      >
                        <td style={{ padding: "12px 14px", color: "#1D9E75", fontWeight: 600 }}>{b.id}</td>
                        <td style={{ padding: "12px 14px", color: "#fff", whiteSpace: "nowrap" }}>
                          <div style={{ fontWeight: 600 }}>{b.user}</div>
                          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>{b.email}</div>
                        </td>
                        <td style={{ padding: "12px 14px", color: "rgba(255,255,255,0.75)", whiteSpace: "nowrap" }}>
                          <div style={{ fontWeight: 500 }}>{servicesText}</div>
                          {b.services && b.services.length > 1 && (
                            <span style={{ fontSize: 10, background: "rgba(29,158,117,0.1)", color: "#1D9E75", padding: "1px 5px", borderRadius: 4, fontWeight: "bold" }}>Multi-Service</span>
                          )}
                        </td>
                        <td style={{ padding: "12px 14px", color: "rgba(255,255,255,0.55)" }}>{b.vehicle}</td>
                        <td style={{ padding: "12px 14px", color: "rgba(255,255,255,0.55)", whiteSpace: "nowrap" }}>
                          <div>{b.date}</div>
                          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>{b.time}</div>
                        </td>
                        <td style={{ padding: "12px 14px" }}>
                          {isEditing ? (
                            <select value={editData.status} onChange={e => setEditData({ ...editData, status: e.target.value })}
                              style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.2)", color: "#fff", borderRadius: 6, padding: "4px 8px", fontSize: 12 }}>
                              {["Pending", "Confirmed", "In Service", "Completed"].map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                          ) : (
                            <span style={{ background: st.bg, border: `1px solid ${st.border}`, color: st.color, padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, whiteSpace: "nowrap" }}>
                              ● {b.status}
                            </span>
                          )}
                        </td>
                        <td style={{ padding: "12px 14px" }}>
                          {isEditing ? (
                            <select value={editData.mechanic} onChange={e => setEditData({ ...editData, mechanic: e.target.value })}
                              style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.2)", color: "#fff", borderRadius: 6, padding: "4px 8px", fontSize: 12 }}>
                              <option value="Pending">Pending</option>
                              <option value="-">-</option>
                              {mechanics.map(m => <option key={m} value={m}>{m}</option>)}
                            </select>
                          ) : (
                            <span style={{ color: b.mechanic === "Pending" || b.mechanic === "-" ? "rgba(255,255,255,0.3)" : "rgba(255,255,255,0.7)" }}>{b.mechanic}</span>
                          )}
                        </td>
                        <td style={{ padding: "12px 14px", color: "#1D9E75", fontWeight: 700, fontFamily: "'Rajdhani', sans-serif", fontSize: 15 }}>₹{b.totalPrice || b.price}</td>
                        <td style={{ padding: "12px 14px", whiteSpace: "nowrap" }}>
                          {isEditing ? (
                            <div className="d-flex gap-2">
                              <button onClick={() => saveEdit(b.id)} style={{ background: "#1D9E75", border: "none", color: "#fff", borderRadius: 6, padding: "5px 12px", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>Save</button>
                              <button onClick={() => setEditingId(null)} style={{ background: "rgba(255,255,255,0.08)", border: "none", color: "#fff", borderRadius: 6, padding: "5px 10px", cursor: "pointer", fontSize: 12 }}>✕</button>
                            </div>
                          ) : (
                            <button onClick={() => startEdit(b)} style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", color: "rgba(255,255,255,0.65)", borderRadius: 6, padding: "5px 12px", cursor: "pointer", fontSize: 12 }}>✏️ Edit</button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {filteredBookings.length === 0 && (
                <div style={{ textAlign: "center", padding: "40px", color: "rgba(255,255,255,0.3)", fontSize: 14 }}>No bookings found</div>
              )}
            </div>
          </>
        )}

        {/* Users Tab */}
        {activeTab === "users" && (
          <div className="row g-3">
            {[
              { name: "jayaraj", email: "user@jayaraj.com", bookings: bookings.filter(b => b.email === "user@jayaraj.com").length, status: "Active", joined: "May 2025" },
              { name: "Mukesh", email: "admin@mukesh.com", bookings: bookings.filter(b => b.email === "admin@mukesh.com").length, status: "Active", joined: "May 2025" },
            ].map((u) => (
              <div className="col-md-6 col-lg-4" key={u.email}>
                <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 14, padding: "20px 22px" }}>
                  <div className="d-flex align-items-center gap-3 mb-3">
                    <div style={{
                      width: 44, height: 44, borderRadius: "50%",
                      background: "linear-gradient(135deg, #1D9E75, #085041)",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 18, fontWeight: 700, color: "#fff"
                    }}>{u.name.charAt(0)}</div>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 15, color: "#fff", fontFamily: "'Rajdhani', sans-serif" }}>{u.name}</div>
                      <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>{u.email}</div>
                    </div>
                    <div className="ms-auto">
                      <span style={{
                        fontSize: 11, padding: "3px 9px", borderRadius: 20, fontWeight: 600,
                        background: u.status === "Active" ? "rgba(29,158,117,0.12)" : "rgba(108,117,125,0.12)",
                        border: `1px solid ${u.status === "Active" ? "rgba(29,158,117,0.3)" : "rgba(108,117,125,0.3)"}`,
                        color: u.status === "Active" ? "#1D9E75" : "#9ca3af"
                      }}>● {u.status}</span>
                    </div>
                  </div>
                  <div className="d-flex gap-3">
                    <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: 8, padding: "8px 14px", flex: 1, textAlign: "center" }}>
                      <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 18, color: "#1D9E75" }}>{u.bookings}</div>
                      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>Bookings</div>
                    </div>
                    <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: 8, padding: "8px 14px", flex: 1, textAlign: "center" }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{u.joined}</div>
                      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>Joined</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Mechanics Tab */}
        {activeTab === "mechanics" && (
          <div className="row g-3">
            {[
              { name: "Suresh M.", specialty: "Engine & Oil", tasks: bookings.filter(b => b.mechanic === "Suresh M.").length + 12, rating: "4.8", available: true },
              { name: "Karthik R.", specialty: "Wheel & Suspension", tasks: bookings.filter(b => b.mechanic === "Karthik R.").length + 9, rating: "4.9", available: true },
              { name: "Mani S.", specialty: "Electrical & Battery", tasks: 7, rating: "4.7", available: false },
              { name: "Raj T.", specialty: "AC & Cooling", tasks: 11, rating: "4.6", available: true },
              { name: "Kumar A.", specialty: "Brakes & Tires", tasks: 8, rating: "4.8", available: false },
            ].map((m) => (
              <div className="col-md-6 col-lg-4" key={m.name}>
                <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 14, padding: "22px 22px" }}>
                  <div className="d-flex align-items-center gap-3 mb-3">
                    <div style={{
                      width: 48, height: 48, borderRadius: "50%",
                      background: m.available ? "linear-gradient(135deg, #1D9E75, #085041)" : "rgba(255,255,255,0.1)",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 20, color: "#fff"
                    }}>🔧</div>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 16, color: "#fff", fontFamily: "'Rajdhani', sans-serif" }}>{m.name}</div>
                      <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>{m.specialty}</div>
                    </div>
                    <div className="ms-auto">
                      <span style={{
                        fontSize: 11, padding: "3px 9px", borderRadius: 20, fontWeight: 600,
                        background: m.available ? "rgba(29,158,117,0.12)" : "rgba(220,53,69,0.1)",
                        border: `1px solid ${m.available ? "rgba(29,158,117,0.3)" : "rgba(220,53,69,0.3)"}`,
                        color: m.available ? "#1D9E75" : "#ff8a8a"
                      }}>● {m.available ? "Available" : "Busy"}</span>
                    </div>
                  </div>
                  <div className="d-flex gap-3">
                    <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: 8, padding: "8px 14px", flex: 1, textAlign: "center" }}>
                      <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 18, color: "#fff" }}>{m.tasks}</div>
                      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>Tasks Done</div>
                    </div>
                    <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: 8, padding: "8px 14px", flex: 1, textAlign: "center" }}>
                      <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 18, color: "#ffc107" }}>⭐ {m.rating}</div>
                      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>Rating</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
