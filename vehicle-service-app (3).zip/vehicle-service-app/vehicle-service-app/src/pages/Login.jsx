import { useState } from "react";
import { api } from "../api";

// Demo accounts for testing
const DEMO_ACCOUNTS = [
  { email: "user@jayaraj.com", password: "user123", name: "jayaraj", role: "user" },
  { email: "admin@mukesh.com", password: "admin123", name: "Mukesh", role: "admin" },
];

export default function Login({ navigate, onLogin }) {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const userData = await api.login(form.email, form.password);
      onLogin(userData);
    } catch (err) {
      setError(err.message || "Invalid email or password. Try user@jayaraj.com / user123");
    } finally {
      setLoading(false);
    }
  };

  const fillDemo = (type) => {
    const acc = DEMO_ACCOUNTS.find((a) => a.role === type);
    setForm({ email: acc.email, password: acc.password });
    setError("");
  };

  return (
    <div style={{
      minHeight: "calc(100vh - 64px)",
      background: "linear-gradient(135deg, #0f2027 0%, #1a3a4a 50%, #0d3b2e 100%)",
      display: "flex", alignItems: "center", justifyContent: "center", padding: "40px 16px"
    }}>
      <div style={{ width: "100%", maxWidth: 440 }}>

        {/* Card */}
        <div style={{
          background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 20, padding: "40px 36px", backdropFilter: "blur(12px)",
          boxShadow: "0 24px 80px rgba(0,0,0,0.5)"
        }}>
          <div className="text-center mb-4">
            <div style={{
              width: 56, height: 56, borderRadius: 14,
              background: "linear-gradient(135deg, #1D9E75, #0d6e56)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 24, margin: "0 auto 16px", boxShadow: "0 0 24px rgba(29,158,117,0.5)"
            }}>🔧</div>
            <h2 style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 26, color: "#fff", marginBottom: 6 }}>Welcome Back</h2>
            <p style={{ color: "rgba(255,255,255,0.45)", fontSize: 14 }}>Sign in to your AutoServe account</p>
          </div>

          {/* Demo quick-fill */}
          <div className="d-flex gap-2 mb-4">
            <button type="button" onClick={() => fillDemo("user")} style={{
              flex: 1, padding: "8px", border: "1px solid rgba(29,158,117,0.35)",
              borderRadius: 8, background: "rgba(29,158,117,0.08)", color: "#1D9E75",
              fontSize: 12, fontWeight: 600, cursor: "pointer"
            }}>🧑  User</button>
            <button type="button" onClick={() => fillDemo("admin")} style={{
              flex: 1, padding: "8px", border: "1px solid rgba(99,130,255,0.35)",
              borderRadius: 8, background: "rgba(99,130,255,0.08)", color: "#8fa7ff",
              fontSize: 12, fontWeight: 600, cursor: "pointer"
            }}>👑Admin</button>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, fontWeight: 500, marginBottom: 6, display: "block" }}>
                Email Address
              </label>
              <input
                type="email" name="email" value={form.email} onChange={handleChange}
                placeholder="you@example.com" required
                style={{
                  width: "100%", padding: "11px 14px", borderRadius: 8, fontSize: 14,
                  background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
                  color: "#fff", outline: "none", transition: "border 0.2s"
                }}
                onFocus={e => e.target.style.borderColor = "rgba(29,158,117,0.6)"}
                onBlur={e => e.target.style.borderColor = "rgba(255,255,255,0.12)"}
              />
            </div>

            <div className="mb-4">
              <label style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, fontWeight: 500, marginBottom: 6, display: "block" }}>
                Password
              </label>
              <div style={{ position: "relative" }}>
                <input
                  type={showPassword ? "text" : "password"} name="password"
                  value={form.password} onChange={handleChange}
                  placeholder="Enter password" required
                  style={{
                    width: "100%", padding: "11px 40px 11px 14px", borderRadius: 8, fontSize: 14,
                    background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
                    color: "#fff", outline: "none", transition: "border 0.2s"
                  }}
                  onFocus={e => e.target.style.borderColor = "rgba(29,158,117,0.6)"}
                  onBlur={e => e.target.style.borderColor = "rgba(255,255,255,0.12)"}
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} style={{
                  position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)",
                  background: "none", border: "none", color: "rgba(255,255,255,0.4)",
                  cursor: "pointer", fontSize: 16, lineHeight: 1
                }}>{showPassword ? "🙈" : "👁️"}</button>
              </div>
            </div>

            {error && (
              <div style={{
                background: "rgba(220,53,69,0.12)", border: "1px solid rgba(220,53,69,0.3)",
                borderRadius: 8, padding: "10px 14px", marginBottom: 16,
                color: "#ff8a8a", fontSize: 13
              }}>{error}</div>
            )}

            <button type="submit" disabled={loading} style={{
              width: "100%", padding: "13px", borderRadius: 8, border: "none",
              background: loading ? "rgba(29,158,117,0.4)" : "linear-gradient(135deg, #1D9E75, #0d6e56)",
              color: "#fff", fontWeight: 700, fontSize: 15, cursor: loading ? "not-allowed" : "pointer",
              boxShadow: loading ? "none" : "0 4px 20px rgba(29,158,117,0.4)",
              fontFamily: "'Rajdhani', sans-serif", letterSpacing: 0.5, transition: "all 0.2s"
            }}>
              {loading ? "Signing in..." : "Sign In →"}
            </button>
          </form>

          <div className="text-center mt-4">
            <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 14 }}>Don't have an account? </span>
            <button onClick={() => navigate("register")} style={{
              background: "none", border: "none", color: "#1D9E75",
              fontWeight: 600, fontSize: 14, cursor: "pointer", textDecoration: "underline"
            }}>Create account</button>
          </div>
        </div>
      </div>
    </div>
  );
}
