const BASE_URL = "http://localhost:5000/api";

// Helper to attach authorization header automatically
const getHeaders = (hasBody = true) => {
  const headers = {};
  if (hasBody) {
    headers["Content-Type"] = "application/json";
  }
  const token = localStorage.getItem("autoserve_token");
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  return headers;
};

// Error handling helper
async function handleResponse(response) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.message || "An unexpected error occurred");
  }
  return data;
}

export const api = {
  // Auth
  login: async (email, password) => {
    const res = await fetch(`${BASE_URL}/auth/login`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({ email, password })
    });
    const data = await handleResponse(res);
    if (data.token) {
      localStorage.setItem("autoserve_token", data.token);
    }
    return data.user;
  },

  register: async (name, email, phone, password) => {
    const res = await fetch(`${BASE_URL}/auth/register`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({ name, email, phone, password })
    });
    const data = await handleResponse(res);
    if (data.token) {
      localStorage.setItem("autoserve_token", data.token);
    }
    return data.user;
  },

  getMe: async () => {
    const token = localStorage.getItem("autoserve_token");
    if (!token) return null;

    const res = await fetch(`${BASE_URL}/auth/me`, {
      method: "GET",
      headers: getHeaders(false)
    });
    return await handleResponse(res);
  },

  logout: () => {
    localStorage.removeItem("autoserve_token");
  },

  // Vehicles
  getVehicles: async () => {
    const res = await fetch(`${BASE_URL}/vehicles`, {
      method: "GET",
      headers: getHeaders(false)
    });
    return await handleResponse(res);
  },

  addVehicle: async (vehicle) => {
    const res = await fetch(`${BASE_URL}/vehicles`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(vehicle)
    });
    return await handleResponse(res);
  },

  deleteVehicle: async (id) => {
    const res = await fetch(`${BASE_URL}/vehicles/${id}`, {
      method: "DELETE",
      headers: getHeaders(false)
    });
    return await handleResponse(res);
  },

  // Bookings
  getBookings: async () => {
    const res = await fetch(`${BASE_URL}/bookings`, {
      method: "GET",
      headers: getHeaders(false)
    });
    return await handleResponse(res);
  },

  createBooking: async (booking) => {
    const res = await fetch(`${BASE_URL}/bookings`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(booking)
    });
    return await handleResponse(res);
  },

  updateBookingAdmin: async (id, updates) => {
    const res = await fetch(`${BASE_URL}/bookings/${id}`, {
      method: "PUT",
      headers: getHeaders(),
      body: JSON.stringify(updates)
    });
    return await handleResponse(res);
  },

  // Utility data lists
  getServices: async () => {
    const res = await fetch(`${BASE_URL}/services`);
    return await handleResponse(res);
  },

  getMechanics: async () => {
    const res = await fetch(`${BASE_URL}/mechanics`);
    return await handleResponse(res);
  }
};
