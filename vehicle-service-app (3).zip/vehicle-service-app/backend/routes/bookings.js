import express from "express";
import { db } from "../db.js";
import authMiddleware from "../middleware/auth.js";

const router = express.Router();

// Apply auth middleware to all booking routes
router.use(authMiddleware);

// @route   GET api/bookings
// @desc    Get bookings (User's own bookings, or all bookings if admin)
router.get("/", (req, res) => {
  try {
    const bookings = db.getBookings(req.user.id, req.user.role);
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch bookings" });
  }
});

// @route   POST api/bookings
// @desc    Create a new booking (Supports multi-service selection)
router.post("/", (req, res) => {
  const { services, totalPrice, vehicle, date, time, notes } = req.body;

  if (!services || !Array.isArray(services) || services.length === 0) {
    return res.status(400).json({ message: "At least one service must be selected" });
  }
  if (!vehicle || !date || !time) {
    return res.status(400).json({ message: "Vehicle, date, and time slot are required" });
  }

  try {
    const newBooking = db.addBooking(req.user.id, req.user.name, req.user.email, {
      services,
      totalPrice: Number(totalPrice),
      vehicle,
      date,
      time,
      notes: notes || ""
    });
    res.status(201).json(newBooking);
  } catch (err) {
    res.status(500).json({ message: "Failed to create booking" });
  }
});

// @route   PUT api/bookings/:id
// @desc    Update booking details (Status, mechanic, etc. - Admin only)
router.put("/:id", (req, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ message: "Access denied: Admin role required" });
  }

  const { status, mechanic } = req.body;
  const updates = {};
  if (status !== undefined) updates.status = status;
  if (mechanic !== undefined) updates.mechanic = mechanic;

  try {
    const updated = db.updateBooking(req.params.id, updates);
    if (updated) {
      res.json(updated);
    } else {
      res.status(404).json({ message: "Booking not found" });
    }
  } catch (err) {
    res.status(500).json({ message: "Failed to update booking" });
  }
});

export default router;
