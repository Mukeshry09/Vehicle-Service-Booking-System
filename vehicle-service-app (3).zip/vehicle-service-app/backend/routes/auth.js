import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db } from "../db.js";
import authMiddleware, { JWT_SECRET } from "../middleware/auth.js";

const router = express.Router();

// @route   POST api/auth/register
// @desc    Register a new user
router.post("/register", (req, res) => {
  const { name, email, password, phone } = req.body;

  if (!name || !email || !password || !phone) {
    return res.status(400).json({ message: "Please enter all required fields" });
  }

  // Check if user exists
  const existingUser = db.getUserByEmail(email);
  if (existingUser) {
    return res.status(400).json({ message: "User already exists with this email" });
  }

  try {
    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(password, salt);

    const newUser = db.addUser({
      name,
      email,
      passwordHash,
      role: "user", // Default is customer
      phone
    });

    const token = jwt.sign(
      { id: newUser.id, role: newUser.role, name: newUser.name, email: newUser.email },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.status(201).json({
      token,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        phone: newUser.phone,
        joined: newUser.joined
      }
    });
  } catch (err) {
    res.status(500).json({ message: "Registration failed, server error" });
  }
});

// @route   POST api/auth/login
// @desc    Authenticate user & get token
router.post("/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Please enter all fields" });
  }

  const user = db.getUserByEmail(email);
  if (!user) {
    return res.status(400).json({ message: "Invalid credentials" });
  }

  try {
    const isMatch = bcrypt.compareSync(password, user.passwordHash);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign(
      { id: user.id, role: user.role, name: user.name, email: user.email },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        joined: user.joined
      }
    });
  } catch (err) {
    res.status(500).json({ message: "Login failed, server error" });
  }
});

// @route   GET api/auth/me
// @desc    Get current user details
router.get("/me", authMiddleware, (req, res) => {
  const user = db.getUserById(req.user.id);
  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }

  res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    phone: user.phone,
    joined: user.joined
  });
});

export default router;
