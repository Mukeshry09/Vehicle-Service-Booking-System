import express from "express";
import { db } from "../db.js";
import authMiddleware from "../middleware/auth.js";

const router = express.Router();

// Apply auth middleware to all vehicle routes
router.use(authMiddleware);

// @route   GET api/vehicles
// @desc    Get all vehicles of logged in user
router.get("/", (req, res) => {
  try {
    const vehicles = db.getVehicles(req.user.id);
    res.json(vehicles);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch vehicles" });
  }
});

// @route   POST api/vehicles
// @desc    Add a new vehicle
router.post("/", (req, res) => {
  const { name, plate, fuel, model } = req.body;

  if (!name || !plate) {
    return res.status(400).json({ message: "Vehicle name and license plate are required" });
  }

  try {
    const newVehicle = db.addVehicle(req.user.id, {
      name,
      plate,
      fuel: fuel || "Petrol",
      model: model || "2022"
    });
    res.status(201).json(newVehicle);
  } catch (err) {
    res.status(500).json({ message: "Failed to add vehicle" });
  }
});

// @route   DELETE api/vehicles/:id
// @desc    Delete a vehicle
router.delete("/:id", (req, res) => {
  try {
    const success = db.deleteVehicle(req.user.id, req.params.id);
    if (success) {
      res.json({ success: true, message: "Vehicle deleted successfully" });
    } else {
      res.status(404).json({ message: "Vehicle not found" });
    }
  } catch (err) {
    res.status(500).json({ message: "Failed to delete vehicle" });
  }
});

export default router;
